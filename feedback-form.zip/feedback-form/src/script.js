var form = document.getElementById("fs-frm");

async function handleSubmit(event) {
  event.preventDefault();
  var status = document.getElementById("fs-frm-status");
  var submit = document.getElementById("fs-frm-submit");
  var data = new FormData(event.target);

  submit.setAttribute('disabled', true);
  
  fetch(event.target.action, {
    method: form.method,
    body: data,
    headers: {
      'Accept': 'application/json'
    }
  }).then(response => {
    if (response.ok) {
      status.innerHTML = "Thanks for your message!";
      submit.removeAttribute('disabled');
      form.reset()
    } else {
      submit.removeAttribute('disabled');
      form.reset()
      response.json().then(data => {
        if (Object.hasOwn(data, 'errors')) {
          status.innerHTML = data["errors"].map(error => error["message"]).join(", ")
        } else {
          status.innerHTML = "Oops! There was a problem submitting your form"
        }
      })
    }
  }).catch(error => {
    status.innerHTML = "Oops! There was a problem submitting your form"
    submit.removeAttribute('disabled');
  });
}
form.addEventListener("submit", handleSubmit)

function openNav() {
  document.getElementById("mySidenav").style.width = "250px";
}

function closeNav() {
  document.getElementById("mySidenav").style.width = "0";
}